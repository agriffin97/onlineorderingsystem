<?php


$host = "localhost";
$dbname = "login_db";
$username = "root";
$password = "";

$conn = new mysqli(    $host,
                        $username,
                        $password,
                        $dbname);

                       
                        if ($conn->mysqliect_errno) {
                            die("mysqliection failed: " . $conn->mysqliect_error);
                        }
                        
                        return $conn;

                        