<?php

session_start();

if (isset($_SESSION["user_id"])) {
    $conn = require __DIR__ . "/database.php";

    $sql = "SELECT * FROM user
    WHERE id = {$_SESSION["user_id"]}";

    $result = $conn->query($sql);
    $user = $result->fetch_assoc();

}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food HQ</title>
    <link rel="stylesheet" href="css/styles.css">
</head>


<?php if (isset($user)): ?>
        <p>Hello <?= htmlspecialchars($user["firstname"]) ?> </p> 
        <p><a href="logout.php">Log Out</a></p>

            <?php endif; ?>

<body>

<section class="navbar">
    <div class="container">
        <div class = "logo">
            <img src="images/logo.png" alt="Logo" class="img-responsive">
        </div>

        <div class="menu text-right">
            <ul>
            <li>
                <a href="index.php">Home</a>
            </li>
            <li>
                <a href="#">Foods</a>
            </li>
            <li class="cart">
                <a href="#">Cart<span></span></a>
            </li>
            <li>
                <a href="signup.html">Signup</a>
            </li>


            </ul>
        </div>
        <div class="clear"></div>
    </div>
</section>

<div class="products-container">
    <div class="product-header">
        <h5 class="product-title">PRODUCT</h5>
        <h5 class="price">PRICE</h5>
        <h5 class="quantity">QUANTITY</h5>
        <h5 class="total">TOTAL</h5>
    </div>
    <div class="products">

    </div>
</div>

<section class = "footer">
    <div class="container">
        <p>If you would like to contact us, please call us on 0151-123-456, or email  at <a href="#"> foodhq@outlook.com</a></p>
    </div>
</section>    
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<script src="main.js"></script>
</body>
</html>