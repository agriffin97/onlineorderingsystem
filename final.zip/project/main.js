let carts = document.querySelectorAll(".add-cart");

let products = [
  {
    name: "Chicken Wrap",
    tag: "chickenwrap",
    price: 5,
    inCart: 0,
  },
  {
    name: "Cheese Pizza",
    tag: "cheesepizza",
    price: 9,
    inCart: 0,
  },
  {
    name: "Chicken Bucket",
    tag: "chickenbucket",
    price: 6,
    inCart: 0,
  },
  {
    name: "Burger Meal",
    tag: "burgermeal",
    price: 5.99,
    inCart: 0,
  },
];

for (let i = 0; i < carts.length; i++) {
  carts[i].addEventListener("click", () => {
    cartNumbers(products[i]);
    console.log(totalCost(products[i]));
  });
}

function onLoadCartNumbers() {
  let productNumbers = localStorage.getItem("cartNumbers");
  if (productNumbers) {
    document.querySelector(".cart span").textContent = productNumbers;
  }
}

function cartNumbers(product) {
  let productNumbers = localStorage.getItem("cartNumbers");

  productNumbers = parseInt(productNumbers);

  if (productNumbers) {
    localStorage.setItem("cartNumbers", productNumbers + 1);
    document.querySelector(".cart span").textContent = productNumbers + 1;
  } else {
    localStorage.setItem("cartNumbers", 1);
    document.querySelector(".cart span").textContent = 1;
  }

  setItems(product);
}

function setItems(product) {
  let cartItems = localStorage.getItem("productsInCart");
  cartItems = JSON.parse(cartItems);

  if (cartItems != null) {
    if (cartItems[product.tag] == undefined) {
      cartItems = {
        ...cartItems,
        [product.tag]: product,
      };
    }
    cartItems[product.tag].inCart += 1;
  } else {
    product.inCart = 1;
    cartItems = {
      [product.tag]: product,
    };
  }
  localStorage.setItem("productsInCart", JSON.stringify(cartItems));
}

function totalCost(product) {
  // console.log("The total price is ", product.price);
  let cartCost = localStorage.getItem("totalCost");

  console.log("My cartCost is", cartCost);
  console.log(typeof cartCost);

  if (cartCost != null) {
    cartCost = parseFloat(cartCost);
    localStorage.setItem("totalCost", cartCost + product.price);
  } else {
    localStorage.setItem("totalCost", product.price);
  }
}

function displayCart() {
  let cartItems = localStorage.getItem("productsInCart");
  cartItems = JSON.parse(cartItems);
  let productContainer = document.querySelector(".products");
  let cartCost = localStorage.getItem("totalCost");

  if (cartItems && productContainer) {
    productContainer.innerHTML = "";
    Object.values(cartItems).map((item) => {
      function productContent(tag, name, price, inCart) {
        return (productContainer.innerHTML += ` 
        <div class='product-wrapper'>
            <div class="product">
                <span>${name}</span>
                <img class = 'product-img' src="./images/${tag}.png">
                <ion-icon class='delete-btn' name="close-outline"></ion-icon>
                </div>
                <div class="price product-price">
                £${price}
                </div>
                <div class="quantity product-quantity">
                <ion-icon class="caret-back-outline" name="caret-back-outline"></ion-icon>
                <span>${inCart}</span>
                <ion-icon class="caret-forward-outline" name="caret-forward-outline"></ion-icon>
                </div>
                <div class="total product-total-price">
                £${(inCart * price).toFixed(2)}
                </div>
                </div>
            `);
      }

      setTimeout(() => {
        var decrement = document.querySelectorAll(".caret-back-outline");
        var increment = document.querySelectorAll(".caret-forward-outline");
        var deleteBtn = document.querySelectorAll(".delete-btn");
        var basketTotal = document.querySelector(".basketTotal");
        var cartText = document.querySelector(".cart").children[0].children[0]

        deleteBtn.forEach((btn) => {
          btn.addEventListener("click", () => {
            var deleteDiv = btn.parentElement.parentElement;
            var selectedProduct = btn.previousElementSibling.previousElementSibling.textContent.trim();
            console.log(selectedProduct)
            if (item.name == selectedProduct) {
              var tag = item.tag;
              var items = JSON.parse(localStorage.getItem("productsInCart"));
              var cartNumber = JSON.parse(localStorage.getItem("cartNumbers"));
              console.log(cartNumber)
              for (key in items) {
                if (tag == key) {
                  cartCost = cartCost - items[key].price * items[key].inCart;
                  localStorage.setItem("cartNumbers", cartNumber - items[key].inCart);
                  cartText.innerHTML= cartNumber - items[key].inCart
                  deleteDiv.remove();
                  delete items[key];
                }
              }
              basketTotal.innerHTML = `£${Number(cartCost).toFixed(2)}`;
              localStorage.setItem("productsInCart", JSON.stringify(items));
              localStorage.setItem("totalCost", Number(cartCost).toFixed(2));
            }
          });
        });

        function quantityChange(selector, operator) {
          selector.forEach((btn) => {
            btn.addEventListener("click", () => {
              var productName =
                btn.parentElement.previousElementSibling.previousElementSibling.children[0].textContent.trim();
              if (operator == "-") {
                var productCount = btn.nextElementSibling;
              } else {
                productCount = btn.previousElementSibling;
              }
              var totalPrice = btn.parentElement.nextElementSibling;
              if (item.name == productName) {
                var items = JSON.parse(localStorage.getItem("productsInCart"));
              var cartNumber = JSON.parse(localStorage.getItem("cartNumbers"));
                for (key in items) {
                  if (item.tag == key) {
                    items[key].inCart = eval(items[key].inCart + operator + 1);
                    cartCost = eval(
                      Number(cartCost) + operator + items[key].price
                    );
                    basketTotal.innerHTML = `£${Number(cartCost).toFixed(2)}`;
                    localStorage.setItem("cartNumbers", eval(cartNumber + operator + 1));
                    cartText.innerHTML = JSON.parse(localStorage.getItem("cartNumbers"));
                  }
                }
                localStorage.setItem("productsInCart", JSON.stringify(items));
                localStorage.setItem("totalCost", Number(cartCost).toFixed(2));

                productCount.innerHTML = item.inCart = eval(
                  item.inCart + operator + 1
                );
                totalPrice.innerHTML = `£${(item.inCart * item.price).toFixed(
                  2
                )}`;
              }
            });
          });
        }

        quantityChange(decrement, "-");
        quantityChange(increment, "+");
      }, 10);
      productContent(item.tag, item.name, item.price, item.inCart);
    });
    productContainer.innerHTML += `  
        <div class="basketTotalContainer">
        <h4 class="basketTotalTitle">
            Basket Total
            </h4>
            <h4 class="basketTotal">
            £${Number(cartCost).toFixed(2)}
            </h4>
        
        `;
  }
}

onLoadCartNumbers();
displayCart();
