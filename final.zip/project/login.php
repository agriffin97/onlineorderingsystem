<?php

$is_invalid = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $conn = require __DIR__ . "/database.php";

    $sql = sprintf("SELECT * FROM user
                    WHERE email = '%s'",
                    $conn->real_escape_string($_POST["email"]));

                    $result = $conn->query($sql);

                    $user = $result->fetch_assoc();

                    if ($user) {

                        if (password_verify($_POST["password"], $user["password_hash"])) {
                                
                            session_start();

                            session_regenerate_id();

                            $_SESSION["user_id"] = $user["id"];

                            header("Location: index.php");
                            exit;



                        }
                    }
                    $is_invalid = true;
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food HQ</title>
    <link rel="stylesheet" href="css/styles.css">
</head>

<section class="navbar">
    <div class="container">
        <div class = "logo">
            <img src="images/logo.png" alt="Logo" class="img-responsive">
        </div>

        <div class="menu text-right">
            <ul>
            <li>
            <a href="index.php">Home</a>
            </li>
            <li>
                <a href="login.php">Log In</a>
            </li>
            <li class="cart">
                <a href="cart.php">Cart<span>0</span>
                    
                </a>
            </li>
                
            </li>
            <li>
                <a href="signup.html">Signup</a>
            </li>


            </ul>
        </div>
        <div class="clear"></div>
    </div>
</section>

            <?php if ($is_invalid): ?>
            <em>Invalid login.</em>
            <?php endif; ?>

            
       
            <form method="post">
                <label for ="email">Email</label>
                <input type="email" name="email" id="email">

                <label for="password">Password</label>
                <input type="password" name="password" id="password">

                <button>Log in</button>
</form>

</body>
</html>