<?php

session_start();

if (isset($_SESSION["user_id"])) {
    $conn = require __DIR__ . "/database.php";

    $sql = "SELECT * FROM user
    WHERE id = {$_SESSION["user_id"]}";

    $result = $conn->query($sql);
    $user = $result->fetch_assoc();

}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food HQ</title>
    <link rel="stylesheet" href="css/styles.css">
</head>


<?php if (isset($user)): ?>
        <p>Hello <?= htmlspecialchars($user["firstname"]) ?> </p> 
        <p><a href="logout.php">Log Out</a></p>

            <?php endif; ?>

<body>

<section class="navbar">
    <div class="container">
        <div class = "logo">
            <img src="images/logo.png" alt="Logo" class="img-responsive">
        </div>

        <div class="menu text-right">
            <ul>
            <li>
                <a href="#">Home</a>
            </li>
            <li>
                <a href="login.php">Log In</a>
            </li>
            <li class="cart">
                <a href="cart.php">
                    Cart<span>0</span>
                </a>
            </li>
                
            </li>
            <li>
                <a href="signup.html">Signup</a>
            </li>


            </ul>
        </div>
        <div class="clear"></div>
    </div>
</section>

<section class = "food-search text-center">
<div class="container search-container">

    <form action="">
        <input type="search" name="search" placeholder="Search here...">
        <input type="submit" name="submit" value="Search" class="btn btn-primary">
    </form>

</div>
</section>
<div class="menucontainer">
    <div class="image">
        <img src="images/chickenwrap.png" alt="chickenwrap">
        <h3>Chicken Wrap</h3>
        <h3>£5.00</h3>
        <a class="add-cart cart1" href="#">Add Cart</a>
    </div>
    <div class="menucontainer">
        <div class="image">
            <img src="images/cheesepizza.png" alt="cheesepizza">
            <h3>Cheese Pizza</h3>
            <h3>£9.00</h3>
            <a class="add-cart cart2" href="#">Add Cart</a>
        </div>
        <div class="menucontainer">
            <div class="image">
                <img src="images/chickenbucket.png" alt="chickenbucket">
                <h3>Chicken Bucket</h3>
                <h3>£6.00</h3>
                <a class="add-cart cart3" href="#">Add Cart</a>
            </div>
        <div class="menucontainer">
                <div class="image">
                    <img src="images/burgermeal.png" alt="burgermeal">
                    <h3>Burger Meal</h3>
                    <h3>£5.99</h3>
                    <a class="add-cart cart4" href="">Add Cart</a>
                </div>
</div>

        <div class="clear"></div>
    </div>
    
</section>

<section class = "footer">
    <div class="container">
        <p>If you would like to contact us, please call us on 0151-123-456, or email  at <a href="#"> foodhq@outlook.com</a></p>
    </div>
</section>    
<script src="main.js"></script>
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>
</html>